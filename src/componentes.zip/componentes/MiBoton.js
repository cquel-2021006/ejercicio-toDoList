import React from 'react'

export const MiBoton = () => {
    let saludo = "Bienvenidos!";
    
    return (
        <button> Mi primer boton React {saludo}</button>
    )
}
